from enum import Enum


class TypeOfGoods(Enum):
    PLUMBING = 0
    WOODEN_GOODS = 1
    LIGHTNING = 2
