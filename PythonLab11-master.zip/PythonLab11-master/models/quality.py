from enum import Enum


class Quality(Enum):
    SHORT_TERM = 0
    MEDIUM_TERM = 1
    LONG_TERM = 2
