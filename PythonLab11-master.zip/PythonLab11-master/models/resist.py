from enum import Enum


class Resist(Enum):
    NO_RESIST = 0
    WEAK_RESIST = 1
    STRONG_RESIST = 2
